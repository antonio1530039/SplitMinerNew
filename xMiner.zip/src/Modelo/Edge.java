package Modelo;


public class Edge{

   public Character tarjet;
   public int freq;
   
   public Edge(Character t, int f){
   this.tarjet = t;
   this.freq = f; 
   }
   
}
