
package Modelo;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;


public class SignificantContext {
    
    public int Frecuency = 1;
    
    public LinkedHashMap<LinkedHashSet<Character>, Integer> ProbableSubsequences = new LinkedHashMap<>();
    //public LinkedHashSet<LinkedHashSet<Character>> ProbableSubsequences = new LinkedHashSet<>();
    
    
}
